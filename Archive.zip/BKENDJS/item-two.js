
//Image selection Section

function model(){
    document.getElementById("model-t").style.display = "block" ;
    document.getElementById("colour1img").style.display = "none" ;
    document.getElementById("colour2img").style.display = "none" ;
    document.getElementById("colour3img").style.display = "none" ;
    document.getElementById("colour4img").style.display = "none" ;
    document.getElementById("colour5img").style.display = "none" ;
    document.getElementById("colour6img").style.display = "none" ;
    document.getElementById("colour7img").style.display = "none" ;
    document.getElementById("colour8img").style.display = "none" ;
    document.getElementById("colour9img").style.display = "none" ;
    document.getElementById("colour10img").style.display = "none" ;
    document.getElementById("colour11img").style.display = "none" ;
    document.getElementById("colour12img").style.display = "none" ;

var selectedDesigns = [];
    var checkboxes = document.getElementsByName("colourcheck");
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i].checked) {
            selectedDesigns.push(checkboxes[i].value);
        }
    }
    if (selectedDesigns.length === 0) {
        document.getElementById("model-t").style.display = "block" ;
        document.getElementById("colour1img").style.display = "none" ;
        document.getElementById("colour2img").style.display = "none" ;
        document.getElementById("colour3img").style.display = "none" ;
        document.getElementById("colour4img").style.display = "none" ;
        document.getElementById("colour5img").style.display = "none" ;
        document.getElementById("colour6img").style.display = "none" ;
        document.getElementById("colour7img").style.display = "none" ;
        document.getElementById("colour8img").style.display = "none" ;
        document.getElementById("colour9img").style.display = "none" ;
        document.getElementById("colour10img").style.display = "none" ;
        document.getElementById("colour11img").style.display = "none" ;
        document.getElementById("colour12img").style.display = "none" ;
        document.getElementById("colour13img").style.display = "none" ;
        document.getElementById("colour14img").style.display = "none" ;
    } 

}
function colour1(){
    document.getElementById("model-t").style.display = "none" ;
    document.getElementById("colour1img").style.display = "block" ;
    document.getElementById("colour2img").style.display = "none" ;
    document.getElementById("colour3img").style.display = "none" ;
    document.getElementById("colour4img").style.display = "none" ;
    document.getElementById("colour5img").style.display = "none" ;
    document.getElementById("colour6img").style.display = "none" ;
    document.getElementById("colour7img").style.display = "none" ;
    document.getElementById("colour8img").style.display = "none" ;
    document.getElementById("colour9img").style.display = "none" ;
    document.getElementById("colour10img").style.display = "none" ;
    document.getElementById("colour11img").style.display = "none" ;
    document.getElementById("colour12img").style.display = "none" ;
    document.getElementById("colour13img").style.display = "none" ;
    document.getElementById("colour14img").style.display = "none" ;
    
        document.getElementById("selectedDesignImage").style.display= "" ;
var selectedDesigns = [];
    var checkboxes = document.getElementsByName("colourcheck");
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i].checked) {
            selectedDesigns.push(checkboxes[i].value);
        }
    }
    if (selectedDesigns.length === 0) {
        document.getElementById("model-t").style.display = "block" ;
        document.getElementById("colour1img").style.display = "none" ;
        document.getElementById("colour2img").style.display = "none" ;
        document.getElementById("colour3img").style.display = "none" ;
        document.getElementById("colour4img").style.display = "none" ;
        document.getElementById("colour5img").style.display = "none" ;
        document.getElementById("colour6img").style.display = "none" ;
        document.getElementById("colour7img").style.display = "none" ;
        document.getElementById("colour8img").style.display = "none" ;
        document.getElementById("colour9img").style.display = "none" ;
        document.getElementById("colour10img").style.display = "none" ;
        document.getElementById("colour11img").style.display = "none" ;
        document.getElementById("colour12img").style.display = "none" ;
        document.getElementById("colour13img").style.display = "none" ;
        document.getElementById("colour14img").style.display = "none" ;
    } 
    
}
function colour2(){
    document.getElementById("model-t").style.display = "none" ;
    document.getElementById("colour1img").style.display = "none" ;
    document.getElementById("colour2img").style.display = "block" ;
    document.getElementById("colour3img").style.display = "none" ;
    document.getElementById("colour4img").style.display = "none" ;
    document.getElementById("colour5img").style.display = "none" ;
    document.getElementById("colour6img").style.display = "none" ;
    document.getElementById("colour7img").style.display = "none" ;
    document.getElementById("colour8img").style.display = "none" ;
    document.getElementById("colour9img").style.display = "none" ;
    document.getElementById("colour10img").style.display = "none" ;
    document.getElementById("colour11img").style.display = "none" ;
    document.getElementById("colour12img").style.display = "none" ;
    document.getElementById("colour13img").style.display = "none" ;
    document.getElementById("colour14img").style.display = "none" ;
    
        document.getElementById("selectedDesignImage").style.display= "" ;
var selectedDesigns = [];
    var checkboxes = document.getElementsByName("colourcheck");
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i].checked) {
            selectedDesigns.push(checkboxes[i].value);
        }
    }
    if (selectedDesigns.length === 0) {
        document.getElementById("model-t").style.display = "block" ;
        document.getElementById("colour1img").style.display = "none" ;
        document.getElementById("colour2img").style.display = "none" ;
        document.getElementById("colour3img").style.display = "none" ;
        document.getElementById("colour4img").style.display = "none" ;
        document.getElementById("colour5img").style.display = "none" ;
        document.getElementById("colour6img").style.display = "none" ;
        document.getElementById("colour7img").style.display = "none" ;
        document.getElementById("colour8img").style.display = "none" ;
        document.getElementById("colour9img").style.display = "none" ;
        document.getElementById("colour10img").style.display = "none" ;
        document.getElementById("colour11img").style.display = "none" ;
        document.getElementById("colour12img").style.display = "none" ;
        document.getElementById("colour13img").style.display = "none" ;
        document.getElementById("colour14img").style.display = "none" ;
    } 
    
}
function colour3(){
    document.getElementById("model-t").style.display = "none" ;
    document.getElementById("colour1img").style.display = "none" ;
    document.getElementById("colour2img").style.display = "none" ;
    document.getElementById("colour3img").style.display = "block" ;
    document.getElementById("colour4img").style.display = "none" ;
    document.getElementById("colour5img").style.display = "none" ;
    document.getElementById("colour6img").style.display = "none" ;
    document.getElementById("colour7img").style.display = "none" ;
    document.getElementById("colour8img").style.display = "none" ;
    document.getElementById("colour9img").style.display = "none" ;
    document.getElementById("colour10img").style.display = "none" ;
    document.getElementById("colour11img").style.display = "none" ;
    document.getElementById("colour12img").style.display = "none" ;
    document.getElementById("colour13img").style.display = "none" ;
    document.getElementById("colour14img").style.display = "none" ;
    
        document.getElementById("selectedDesignImage").style.display= "" ;
var selectedDesigns = [];
    var checkboxes = document.getElementsByName("colourcheck");
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i].checked) {
            selectedDesigns.push(checkboxes[i].value);
        }
    }
    if (selectedDesigns.length === 0) {
        document.getElementById("model-t").style.display = "block" ;
        document.getElementById("colour1img").style.display = "none" ;
        document.getElementById("colour2img").style.display = "none" ;
        document.getElementById("colour3img").style.display = "none" ;
        document.getElementById("colour4img").style.display = "none" ;
        document.getElementById("colour5img").style.display = "none" ;
        document.getElementById("colour6img").style.display = "none" ;
        document.getElementById("colour7img").style.display = "none" ;
        document.getElementById("colour8img").style.display = "none" ;
        document.getElementById("colour9img").style.display = "none" ;
        document.getElementById("colour10img").style.display = "none" ;
        document.getElementById("colour11img").style.display = "none" ;
        document.getElementById("colour12img").style.display = "none" ;
        document.getElementById("colour13img").style.display = "none" ;
        document.getElementById("colour14img").style.display = "none" ;
    } 
    
}
function colour4(){
    document.getElementById("model-t").style.display = "none" ;
    document.getElementById("colour1img").style.display = "none" ;
    document.getElementById("colour2img").style.display = "none" ;
    document.getElementById("colour3img").style.display = "none" ;
    document.getElementById("colour4img").style.display = "block" ;
    document.getElementById("colour5img").style.display = "none" ;
    document.getElementById("colour6img").style.display = "none" ;
    document.getElementById("colour7img").style.display = "none" ;
    document.getElementById("colour8img").style.display = "none" ;
    document.getElementById("colour9img").style.display = "none" ;
    document.getElementById("colour10img").style.display = "none" ;
    document.getElementById("colour11img").style.display = "none" ;
    document.getElementById("colour12img").style.display = "none" ;
    document.getElementById("colour13img").style.display = "none" ;
    document.getElementById("colour14img").style.display = "none" ;
    
        document.getElementById("selectedDesignImage").style.display= "" ;
var selectedDesigns = [];
    var checkboxes = document.getElementsByName("colourcheck");
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i].checked) {
            selectedDesigns.push(checkboxes[i].value);
        }
    }
    if (selectedDesigns.length === 0) {
        document.getElementById("model-t").style.display = "block" ;
        document.getElementById("colour1img").style.display = "none" ;
        document.getElementById("colour2img").style.display = "none" ;
        document.getElementById("colour3img").style.display = "none" ;
        document.getElementById("colour4img").style.display = "none" ;
        document.getElementById("colour5img").style.display = "none" ;
        document.getElementById("colour6img").style.display = "none" ;
        document.getElementById("colour7img").style.display = "none" ;
        document.getElementById("colour8img").style.display = "none" ;
        document.getElementById("colour9img").style.display = "none" ;
        document.getElementById("colour10img").style.display = "none" ;
        document.getElementById("colour11img").style.display = "none" ;
        document.getElementById("colour12img").style.display = "none" ;
        document.getElementById("colour13img").style.display = "none" ;
        document.getElementById("colour14img").style.display = "none" ;
    } 
    
}
function colour5(){
    document.getElementById("model-t").style.display = "none" ;
    document.getElementById("colour1img").style.display = "none" ;
    document.getElementById("colour2img").style.display = "none" ;
    document.getElementById("colour3img").style.display = "none" ;
    document.getElementById("colour4img").style.display = "none" ;
    document.getElementById("colour5img").style.display = "block" ;
    document.getElementById("colour6img").style.display = "none" ;
    document.getElementById("colour7img").style.display = "none" ;
    document.getElementById("colour8img").style.display = "none" ;
    document.getElementById("colour9img").style.display = "none" ;
    document.getElementById("colour10img").style.display = "none" ;
    document.getElementById("colour11img").style.display = "none" ;
    document.getElementById("colour12img").style.display = "none" ;
    document.getElementById("colour13img").style.display = "none" ;
    document.getElementById("colour14img").style.display = "none" ;
    
        document.getElementById("selectedDesignImage").style.display= "" ;
var selectedDesigns = [];
    var checkboxes = document.getElementsByName("colourcheck");
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i].checked) {
            selectedDesigns.push(checkboxes[i].value);
        }
    }
    if (selectedDesigns.length === 0) {
        document.getElementById("model-t").style.display = "block" ;
        document.getElementById("colour1img").style.display = "none" ;
        document.getElementById("colour2img").style.display = "none" ;
        document.getElementById("colour3img").style.display = "none" ;
        document.getElementById("colour4img").style.display = "none" ;
        document.getElementById("colour5img").style.display = "none" ;
        document.getElementById("colour6img").style.display = "none" ;
        document.getElementById("colour7img").style.display = "none" ;
        document.getElementById("colour8img").style.display = "none" ;
        document.getElementById("colour9img").style.display = "none" ;
        document.getElementById("colour10img").style.display = "none" ;
        document.getElementById("colour11img").style.display = "none" ;
        document.getElementById("colour12img").style.display = "none" ;
        document.getElementById("colour13img").style.display = "none" ;
        document.getElementById("colour14img").style.display = "none" ;
    } 
    
}
function colour6(){
    document.getElementById("model-t").style.display = "none" ;
    document.getElementById("colour1img").style.display = "none" ;
    document.getElementById("colour2img").style.display = "none" ;
    document.getElementById("colour3img").style.display = "none" ;
    document.getElementById("colour4img").style.display = "none" ;
    document.getElementById("colour5img").style.display = "none" ;
    document.getElementById("colour6img").style.display = "block" ;
    document.getElementById("colour7img").style.display = "none" ;
    document.getElementById("colour8img").style.display = "none" ;
    document.getElementById("colour9img").style.display = "none" ;
    document.getElementById("colour10img").style.display = "none" ;
    document.getElementById("colour11img").style.display = "none" ;
    document.getElementById("colour12img").style.display = "none" ;
    document.getElementById("colour13img").style.display = "none" ;
    document.getElementById("colour14img").style.display = "none" ;
    
        document.getElementById("selectedDesignImage").style.display= "" ;
var selectedDesigns = [];
    var checkboxes = document.getElementsByName("colourcheck");
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i].checked) {
            selectedDesigns.push(checkboxes[i].value);
        }
    }
    if (selectedDesigns.length === 0) {
        document.getElementById("model-t").style.display = "block" ;
        document.getElementById("colour1img").style.display = "none" ;
        document.getElementById("colour2img").style.display = "none" ;
        document.getElementById("colour3img").style.display = "none" ;
        document.getElementById("colour4img").style.display = "none" ;
        document.getElementById("colour5img").style.display = "none" ;
        document.getElementById("colour6img").style.display = "none" ;
        document.getElementById("colour7img").style.display = "none" ;
        document.getElementById("colour8img").style.display = "none" ;
        document.getElementById("colour9img").style.display = "none" ;
        document.getElementById("colour10img").style.display = "none" ;
        document.getElementById("colour11img").style.display = "none" ;
        document.getElementById("colour12img").style.display = "none" ;
        document.getElementById("colour13img").style.display = "none" ;
        document.getElementById("colour14img").style.display = "none" ;
    } 
    
}
function colour7(){
    document.getElementById("model-t").style.display = "none" ;
    document.getElementById("colour1img").style.display = "none" ;
    document.getElementById("colour2img").style.display = "none" ;
    document.getElementById("colour3img").style.display = "none" ;
    document.getElementById("colour4img").style.display = "none" ;
    document.getElementById("colour5img").style.display = "none" ;
    document.getElementById("colour6img").style.display = "none" ;
    document.getElementById("colour7img").style.display = "block" ;
    document.getElementById("colour8img").style.display = "none" ;
    document.getElementById("colour9img").style.display = "none" ;
    document.getElementById("colour10img").style.display = "none" ;
    document.getElementById("colour11img").style.display = "none" ;
    document.getElementById("colour12img").style.display = "none" ;
    document.getElementById("colour13img").style.display = "none" ;
    document.getElementById("colour14img").style.display = "none" ;
    
        document.getElementById("selectedDesignImage").style.display= "" ;
var selectedDesigns = [];
    var checkboxes = document.getElementsByName("colourcheck");
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i].checked) {
            selectedDesigns.push(checkboxes[i].value);
        }
    }
    if (selectedDesigns.length === 0) {
        document.getElementById("model-t").style.display = "block" ;
        document.getElementById("colour1img").style.display = "none" ;
        document.getElementById("colour2img").style.display = "none" ;
        document.getElementById("colour3img").style.display = "none" ;
        document.getElementById("colour4img").style.display = "none" ;
        document.getElementById("colour5img").style.display = "none" ;
        document.getElementById("colour6img").style.display = "none" ;
        document.getElementById("colour7img").style.display = "none" ;
        document.getElementById("colour8img").style.display = "none" ;
        document.getElementById("colour9img").style.display = "none" ;
        document.getElementById("colour10img").style.display = "none" ;
        document.getElementById("colour11img").style.display = "none" ;
        document.getElementById("colour12img").style.display = "none" ;
        document.getElementById("colour13img").style.display = "none" ;
        document.getElementById("colour14img").style.display = "none" ;
    } 
    
}
function colour8(){
    document.getElementById("model-t").style.display = "none" ;
    document.getElementById("colour1img").style.display = "none" ;
    document.getElementById("colour2img").style.display = "none" ;
    document.getElementById("colour3img").style.display = "none" ;
    document.getElementById("colour4img").style.display = "none" ;
    document.getElementById("colour5img").style.display = "none" ;
    document.getElementById("colour6img").style.display = "none" ;
    document.getElementById("colour7img").style.display = "none" ;
    document.getElementById("colour8img").style.display = "block" ;
    document.getElementById("colour9img").style.display = "none" ;
    document.getElementById("colour10img").style.display = "none" ;
    document.getElementById("colour11img").style.display = "none" ;
    document.getElementById("colour12img").style.display = "none" ;
    document.getElementById("colour13img").style.display = "none" ;
    document.getElementById("colour14img").style.display = "none" ;
    
        document.getElementById("selectedDesignImage").style.display= "" ;
var selectedDesigns = [];
    var checkboxes = document.getElementsByName("colourcheck");
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i].checked) {
            selectedDesigns.push(checkboxes[i].value);
        }
    }
    if (selectedDesigns.length === 0) {
        document.getElementById("model-t").style.display = "block" ;
        document.getElementById("colour1img").style.display = "none" ;
        document.getElementById("colour2img").style.display = "none" ;
        document.getElementById("colour3img").style.display = "none" ;
        document.getElementById("colour4img").style.display = "none" ;
        document.getElementById("colour5img").style.display = "none" ;
        document.getElementById("colour6img").style.display = "none" ;
        document.getElementById("colour7img").style.display = "none" ;
        document.getElementById("colour8img").style.display = "none" ;
        document.getElementById("colour9img").style.display = "none" ;
        document.getElementById("colour10img").style.display = "none" ;
        document.getElementById("colour11img").style.display = "none" ;
        document.getElementById("colour12img").style.display = "none" ;
        document.getElementById("colour13img").style.display = "none" ;
        document.getElementById("colour14img").style.display = "none" ;
    } 
    
}
function colour9(){
    document.getElementById("model-t").style.display = "none" ;
    document.getElementById("colour1img").style.display = "none" ;
    document.getElementById("colour2img").style.display = "none" ;
    document.getElementById("colour3img").style.display = "none" ;
    document.getElementById("colour4img").style.display = "none" ;
    document.getElementById("colour5img").style.display = "none" ;
    document.getElementById("colour6img").style.display = "none" ;
    document.getElementById("colour7img").style.display = "none" ;
    document.getElementById("colour8img").style.display = "none" ;
    document.getElementById("colour9img").style.display = "block" ;
    document.getElementById("colour10img").style.display = "none" ;
    document.getElementById("colour11img").style.display = "none" ;
    document.getElementById("colour12img").style.display = "none" ;
    document.getElementById("colour13img").style.display = "none" ;
    document.getElementById("colour14img").style.display = "none" ;
    
        document.getElementById("selectedDesignImage").style.display= "" ;
var selectedDesigns = [];
    var checkboxes = document.getElementsByName("colourcheck");
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i].checked) {
            selectedDesigns.push(checkboxes[i].value);
        }
    }
    if (selectedDesigns.length === 0) {
        document.getElementById("model-t").style.display = "block" ;
        document.getElementById("colour1img").style.display = "none" ;
        document.getElementById("colour2img").style.display = "none" ;
        document.getElementById("colour3img").style.display = "none" ;
        document.getElementById("colour4img").style.display = "none" ;
        document.getElementById("colour5img").style.display = "none" ;
        document.getElementById("colour6img").style.display = "none" ;
        document.getElementById("colour7img").style.display = "none" ;
        document.getElementById("colour8img").style.display = "none" ;
        document.getElementById("colour9img").style.display = "none" ;
        document.getElementById("colour10img").style.display = "none" ;
        document.getElementById("colour11img").style.display = "none" ;
        document.getElementById("colour12img").style.display = "none" ;
        document.getElementById("colour13img").style.display = "none" ;
        document.getElementById("colour14img").style.display = "none" ;
    } 
    
}
function colour10(){
    document.getElementById("model-t").style.display = "none" ;
    document.getElementById("colour1img").style.display = "none" ;
    document.getElementById("colour2img").style.display = "none" ;
    document.getElementById("colour3img").style.display = "none" ;
    document.getElementById("colour4img").style.display = "none" ;
    document.getElementById("colour5img").style.display = "none" ;
    document.getElementById("colour6img").style.display = "none" ;
    document.getElementById("colour7img").style.display = "none" ;
    document.getElementById("colour8img").style.display = "none" ;
    document.getElementById("colour9img").style.display = "none" ;
    document.getElementById("colour10img").style.display = "block" ;
    document.getElementById("colour11img").style.display = "none" ;
    document.getElementById("colour12img").style.display = "none" ;
    document.getElementById("colour13img").style.display = "none" ;
    document.getElementById("colour14img").style.display = "none" ;
    
        document.getElementById("selectedDesignImage").style.display= "" ;
var selectedDesigns = [];
    var checkboxes = document.getElementsByName("colourcheck");
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i].checked) {
            selectedDesigns.push(checkboxes[i].value);
        }
    }
    if (selectedDesigns.length === 0) {
        document.getElementById("model-t").style.display = "block" ;
        document.getElementById("colour1img").style.display = "none" ;
        document.getElementById("colour2img").style.display = "none" ;
        document.getElementById("colour3img").style.display = "none" ;
        document.getElementById("colour4img").style.display = "none" ;
        document.getElementById("colour5img").style.display = "none" ;
        document.getElementById("colour6img").style.display = "none" ;
        document.getElementById("colour7img").style.display = "none" ;
        document.getElementById("colour8img").style.display = "none" ;
        document.getElementById("colour9img").style.display = "none" ;
        document.getElementById("colour10img").style.display = "none" ;
        document.getElementById("colour11img").style.display = "none" ;
        document.getElementById("colour12img").style.display = "none" ;
        document.getElementById("colour13img").style.display = "none" ;
        document.getElementById("colour14img").style.display = "none" ;
    } 
    
}
function colour11(){
    document.getElementById("model-t").style.display = "none" ;
    document.getElementById("colour1img").style.display = "none" ;
    document.getElementById("colour2img").style.display = "none" ;
    document.getElementById("colour3img").style.display = "none" ;
    document.getElementById("colour4img").style.display = "none" ;
    document.getElementById("colour5img").style.display = "none" ;
    document.getElementById("colour6img").style.display = "none" ;
    document.getElementById("colour7img").style.display = "none" ;
    document.getElementById("colour8img").style.display = "none" ;
    document.getElementById("colour9img").style.display = "none" ;
    document.getElementById("colour10img").style.display = "none" ;
    document.getElementById("colour11img").style.display = "block" ;
    document.getElementById("colour12img").style.display = "none" ;
    document.getElementById("colour13img").style.display = "none" ;
    document.getElementById("colour14img").style.display = "none" ;
    
        document.getElementById("selectedDesignImage").style.display= "" ;
var selectedDesigns = [];
    var checkboxes = document.getElementsByName("colourcheck");
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i].checked) {
            selectedDesigns.push(checkboxes[i].value);
        }
    }
    if (selectedDesigns.length === 0) {
        document.getElementById("model-t").style.display = "block" ;
        document.getElementById("colour1img").style.display = "none" ;
        document.getElementById("colour2img").style.display = "none" ;
        document.getElementById("colour3img").style.display = "none" ;
        document.getElementById("colour4img").style.display = "none" ;
        document.getElementById("colour5img").style.display = "none" ;
        document.getElementById("colour6img").style.display = "none" ;
        document.getElementById("colour7img").style.display = "none" ;
        document.getElementById("colour8img").style.display = "none" ;
        document.getElementById("colour9img").style.display = "none" ;
        document.getElementById("colour10img").style.display = "none" ;
        document.getElementById("colour11img").style.display = "none" ;
        document.getElementById("colour12img").style.display = "none" ;
        document.getElementById("colour13img").style.display = "none" ;
        document.getElementById("colour14img").style.display = "none" ;
    } 
    
}
function colour12(){
    document.getElementById("model-t").style.display = "none" ;
    document.getElementById("colour1img").style.display = "none" ;
    document.getElementById("colour2img").style.display = "none" ;
    document.getElementById("colour3img").style.display = "none" ;
    document.getElementById("colour4img").style.display = "none" ;
    document.getElementById("colour5img").style.display = "none" ;
    document.getElementById("colour6img").style.display = "none" ;
    document.getElementById("colour7img").style.display = "none" ;
    document.getElementById("colour8img").style.display = "none" ;
    document.getElementById("colour9img").style.display = "none" ;
    document.getElementById("colour10img").style.display = "none" ;
    document.getElementById("colour11img").style.display = "none" ;
    document.getElementById("colour12img").style.display = "block" ;
    document.getElementById("colour13img").style.display = "none" ;
    document.getElementById("colour14img").style.display = "none" ;

        document.getElementById("selectedDesignImage").style.display= "" ;
var selectedDesigns = [];
    var checkboxes = document.getElementsByName("colourcheck");
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i].checked) {
            selectedDesigns.push(checkboxes[i].value);
        }
    }
    if (selectedDesigns.length === 0) {
        document.getElementById("model-t").style.display = "block" ;
        document.getElementById("colour1img").style.display = "none" ;
        document.getElementById("colour2img").style.display = "none" ;
        document.getElementById("colour3img").style.display = "none" ;
        document.getElementById("colour4img").style.display = "none" ;
        document.getElementById("colour5img").style.display = "none" ;
        document.getElementById("colour6img").style.display = "none" ;
        document.getElementById("colour7img").style.display = "none" ;
        document.getElementById("colour8img").style.display = "none" ;
        document.getElementById("colour9img").style.display = "none" ;
        document.getElementById("colour10img").style.display = "none" ;
        document.getElementById("colour11img").style.display = "none" ;
        document.getElementById("colour12img").style.display = "none" ;
        document.getElementById("colour13img").style.display = "none" ;
        document.getElementById("colour14img").style.display = "none" ;
    } 

}
function colour13(){
    document.getElementById("model-t").style.display = "none" ;
    document.getElementById("colour1img").style.display = "none" ;
    document.getElementById("colour2img").style.display = "none" ;
    document.getElementById("colour3img").style.display = "none" ;
    document.getElementById("colour4img").style.display = "none" ;
    document.getElementById("colour5img").style.display = "none" ;
    document.getElementById("colour6img").style.display = "none" ;
    document.getElementById("colour7img").style.display = "none" ;
    document.getElementById("colour8img").style.display = "none" ;
    document.getElementById("colour9img").style.display = "none" ;
    document.getElementById("colour10img").style.display = "none" ;
    document.getElementById("colour11img").style.display = "none" ;
    document.getElementById("colour12img").style.display = "none" ;
    document.getElementById("colour13img").style.display = "block" ;
    document.getElementById("colour14img").style.display = "none" ;

        document.getElementById("selectedDesignImage").style.display= "" ;
var selectedDesigns = [];
    var checkboxes = document.getElementsByName("colourcheck");
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i].checked) {
            selectedDesigns.push(checkboxes[i].value);
        }
    }
    if (selectedDesigns.length === 0) {
        document.getElementById("model-t").style.display = "block" ;
        document.getElementById("colour1img").style.display = "none" ;
        document.getElementById("colour2img").style.display = "none" ;
        document.getElementById("colour3img").style.display = "none" ;
        document.getElementById("colour4img").style.display = "none" ;
        document.getElementById("colour5img").style.display = "none" ;
        document.getElementById("colour6img").style.display = "none" ;
        document.getElementById("colour7img").style.display = "none" ;
        document.getElementById("colour8img").style.display = "none" ;
        document.getElementById("colour9img").style.display = "none" ;
        document.getElementById("colour10img").style.display = "none" ;
        document.getElementById("colour11img").style.display = "none" ;
        document.getElementById("colour12img").style.display = "none" ;
        document.getElementById("colour13img").style.display = "none" ;
        document.getElementById("colour14img").style.display = "none" ;
        
    } 

}
function colour14(){
    document.getElementById("model-t").style.display = "none" ;
    document.getElementById("colour1img").style.display = "none" ;
    document.getElementById("colour2img").style.display = "none" ;
    document.getElementById("colour3img").style.display = "none" ;
    document.getElementById("colour4img").style.display = "none" ;
    document.getElementById("colour5img").style.display = "none" ;
    document.getElementById("colour6img").style.display = "none" ;
    document.getElementById("colour7img").style.display = "none" ;
    document.getElementById("colour8img").style.display = "none" ;
    document.getElementById("colour9img").style.display = "none" ;
    document.getElementById("colour10img").style.display = "none" ;
    document.getElementById("colour11img").style.display = "none" ;
    document.getElementById("colour12img").style.display = "none" ;
    document.getElementById("colour13img").style.display = "none" ;
    document.getElementById("colour14img").style.display = "block" ;

        document.getElementById("selectedDesignImage").style.display= "" ;
var selectedDesigns = [];
    var checkboxes = document.getElementsByName("colourcheck");
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i].checked) {
            selectedDesigns.push(checkboxes[i].value);
        }
    }
    if (selectedDesigns.length === 0) {
        document.getElementById("model-t").style.display = "block" ;
        document.getElementById("colour1img").style.display = "none" ;
        document.getElementById("colour2img").style.display = "none" ;
        document.getElementById("colour3img").style.display = "none" ;
        document.getElementById("colour4img").style.display = "none" ;
        document.getElementById("colour5img").style.display = "none" ;
        document.getElementById("colour6img").style.display = "none" ;
        document.getElementById("colour7img").style.display = "none" ;
        document.getElementById("colour8img").style.display = "none" ;
        document.getElementById("colour9img").style.display = "none" ;
        document.getElementById("colour10img").style.display = "none" ;
        document.getElementById("colour11img").style.display = "none" ;
        document.getElementById("colour12img").style.display = "none" ;
        document.getElementById("colour13img").style.display = "none" ;
        document.getElementById("colour14img").style.display = "none" ;
    } 

}

function selectedDesign(selectedImage) {
    let selectedDesignSrc = selectedImage.src;

    let design = document.getElementById("selectedDesignImage");

    var div = $("#selectedDesignImage");
    //var div2 = $("..selected-design");
    design.style.display = "block";

    div.animate({right: '0px', opacity: '1' }, "fast", function() {
        div.animate({right: '-250px', opacity: '0' }, "fast");
    });
    div.animate({right: '250px', opacity: '0' }, "fast", function() {
        design.src = selectedDesignSrc;
        div.animate({right: '0px', opacity: '1' }, "fast"); 
        scrollToSection('main-section');
    });

    renew();
}

function scrollToSection(sectionId) {
    const section = document.getElementById(sectionId);
    if (section) {
        section.scrollIntoView({ behavior: "smooth" });
    }
}


let item1 = {
    name: "T Shirt",
    price: 2000,
    photo: "../Images/White.webp",
    size: "not selected",
    colour: "not selected",
    weight: 0.3,
    quantity: 0,
    cato : "K-Pop"
};

let itemTotalPrice = 0;

function calc() {
    let qty = document.getElementById("id-quantity").value;
    let cost = item1.price;
    let price = qty * cost;
    document.getElementById("tot").innerHTML = price.toFixed(2);

    let weight = item1.weight * qty;
    document.getElementById("wegt").innerHTML = weight.toFixed(2) + " Kg";

    renew();
}


function adc() {
    //let designCato = document.getElementById("design-cato").value;
    let designCato = item1.cato;
    let qty = document.getElementById("id-quantity").value;
    let total = document.getElementById("tot").innerHTML;
    let weight = document.getElementById("wegt").innerHTML;

    if (qty === "0"){
        $("#popupHead").text("Oops !");
        $("#popupContent").text("Please select the quantity.");
        $("#popupButtons").html("<button type='button' class='btn btn-primary' data-bs-dismiss='modal'>Okay</button>");

        $("#myModal").modal('show');
        return;
    }
    
    let selectedColors = Array.from(document.querySelectorAll('input[name="colourcheck"]:checked')).map(checkbox => checkbox.value);
    
    if (selectedColors.length === 0) {
        $("#popupHead").text("Oops !");
        $("#popupContent").text("Please select a colour.");
        $("#popupButtons").html("<button type='button' class='btn btn-primary' data-bs-dismiss='modal'>Okay</button>");

        $("#myModal").modal('show');
        return;
    }

    let selectedDesignImageSrc = document.getElementById("selectedDesignImage").src;

    
    // URL
    if (selectedDesignImageSrc === "https://animeshop.lk/SITE5/product/item-one/index.html") {
        $("#popupHead").text("Oops !");
        $("#popupContent").text("Please select a design");
        $("#popupButtons").html("<button type='button' class='btn btn-primary' data-bs-dismiss='modal'>Okay</button>");

        $("#myModal").modal('show');
        return;
    }

    let selectedSizes = document.getElementById("size").value;
    if (selectedSizes === "Select a size") {
        $("#popupHead").text("Oops !");
        $("#popupContent").text("Please select a size");
        $("#popupButtons").html("<button type='button' class='btn btn-primary' data-bs-dismiss='modal'>Okay</button>");

        $("#myModal").modal('show');
        return;
    }

    let selectedSide = document.getElementById("side").value;
    if (selectedSide === "Select a side") {
        $("#popupHead").text("Oops !");
        $("#popupContent").text("Please select a side to print");
        $("#popupButtons").html("<button type='button' class='btn btn-primary' data-bs-dismiss='modal'>Okay</button>");

        $("#myModal").modal('show');
        return;
    }

    let content = `
    <div class='card w-100 mb-1' id="itemlist-item">
        <input type="text" name="quantity[]" value="${qty}" style="display: none;">
        <input class="totalof" type="text" name="total[]" value="${total}" style="display: none;">
        <input type="text" name="color[]" value="${selectedColors}" style="display: none;">
        <input type="text" name="size[]" value="${selectedSizes} - ${selectedSide}" style="display: none;">
        <input type="text" name="design[]" value="${selectedDesignImageSrc}" style="display: none;">
        <input class="weightof" type="text" name="weight[]" value="${weight}" style="display: none;">
        <div class="card-body d-flex">
            <div class="col-3">
                <img src="${item1.photo}" alt="" class="rounded" style="width:100%;">
            </div>
            <div class="col-8 ms-4">
                <div class="head d-flex" style="border: 0px solid;">
                    <h5 class="card-title col-11">${item1.name} (${designCato})</h5>
                    <button onclick="closeItem(this)" type="button" class="btn-close col-1"></button>
                </div>
                <p class="card-text">Quantity - ${qty}</p>
                <p class="card-text" id="totalof">Total - Rs. ${total} /-</p>
            </div>
        </div>
    </div>`;


    document.getElementById("item-list").insertAdjacentHTML('beforeend', content);

    let itemList = document.getElementById("item-list").innerHTML;
    localStorage.setItem('cartItemsAnimeShop', itemList);

    document.getElementById("adcbtn").innerHTML = "ADDED TO THE CART";

    $("#popupHead").text("Added to the cart !");
    $("#popupContent").text("Do you want to view your cart?");
    $("#popupButtons").html("<button type='button' class='btn btn-success' data-bs-dismiss='modal' onclick=\"$('#cart').offcanvas('show');\">View Cart</button><button type='button' class='btn btn-primary' data-bs-dismiss='modal'>Shop More</button>");

    $("#myModal").modal('show');
} 


function onLoad() {
    document.getElementById("tot").innerHTML = item1.price.toFixed(2);
    document.getElementById("wegt").innerHTML = "0 Kg";

    let localItems = localStorage.getItem('cartItemsAnimeShop');
    if (localItems && localItems.length > 0) {
        document.getElementById("item-list").innerHTML = localItems;
    }

    document.getElementById("overlay").style.display = "block";

    rows = document.querySelectorAll('.options.table tr');
    for (let i = 1; i < rows.length; i++) {
        rows[i].style.display = 'none';
    }

    document.getElementById("selectedDesignImage").style.display= "none" ;
}

function renew(){
    $('#adcbtn').html('ADD TO CART');
}

function off() {
    document.getElementById("overlay").style.display = "none";
}

function closeItem(element) {
    localStorage.removeItem('cartItemsAnimeShop');
    element.closest('#itemlist-item').remove();
    let itemList = document.getElementById("item-list").innerHTML;
    localStorage.setItem('cartItemsAnimeShop', itemList);

    rmItemTotalPrice = parseFloat(document.getElementById("tot").innerHTML);
    itemTotalPrice -= rmItemTotalPrice;
    localStorage.setItem('itp', itemTotalPrice);
}

function toggleCheckboxes(checkbox) {
    checkboxes = document.getElementsByName("colourcheck");
    checkboxes.forEach(c => {
        if (c !== checkbox) {
            c.checked = false;
        }
    });
}

function checkout(){
    var cartItemTotal = $('#item-list').html(); 
    if (cartItemTotal.length < 180) {
        $("#popupHead").text("Oops !");
        $("#popupContent").text("Please select some items");
        $("#popupButtons").html("<button type='button' class='btn btn-primary' data-bs-dismiss='modal' onclick=\"$('#cart').offcanvas('hide');\">Shop More</button>");

        $("#myModal").modal('show');
    } else {
        window.open("../Order/index.html", "_self")
    }
}

onLoad();
