


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Koomiyo | Delivery</title>

    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

    <style>
        .custom-border{
            border: 1.5px solid #7777bb;
        }
    </style>

</head>
<body>
    <div class="container custom-border h-75 d-flex mt-3 mb-5">
        <div class="col-7  flex-coloumn" style="height: 650px;">
            <img class="mx-auto d-block" width="40%" src="logo.png" alt="">
            <p class="text-center">Address : No.25, Epitamulla Road, Pita Kotte. Tel : +94 117 886 786</p>
            <p class="text-center" style="margin-top: -2%;">Web : koombiyodelivery.lk / Email : info@koombiyodelivery.com</p>

            <?php

$host = "124.43.11.75";
$dbname = "neo_tshirts";
$username = "root";
$password = "r00t1@ne0";

// Create a connection to the database
$conn = new mysqli($host, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

date_default_timezone_set('America/New_York');

// Get the current date in the format "Y-m-d H:i:s"
$currentDate = date("Y-m-d");
// Assuming your table is named 'order_details'
$userId = isset($_POST['id']) ? $_POST['id'] : '';

// Prepare and execute the SQL query
$sql = "SELECT * FROM order_details WHERE contact_no = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();

$result = $stmt->get_result();

// Get the result
if ($result->num_rows > 0) {
    // Fetch the data from the first row
    $row = $result->fetch_assoc();

    echo '<div class="col custom-border pt-3 me-2 rounded pb-1">';
    echo '   <h4 class="ms-3 mt-2">From : Neo Graphics (Pvt) (Ltd)</h4>';
    echo    '<h4 class="ms-3 mt-2 mb-2">Contact Number : +94 76 826 1160</h4>';
    echo    '<h4 class="ms-3 mb-2">Issued Date : ' . $currentDate . '</h4>';
    echo '</div>';

    echo '<div class="col custom-border pt-2 pb-1 me-2 mt-1 rounded" style="height:39%;">';
    echo    '<h4 class="ms-3 mt-2">To : ' . $row['name'] . '</h4>';
    echo    '<h4 class="ms-3 mt-2" style="margin-bottom: 2%;">Address : ' . $row['address'] . '</h4>';
    echo    '<h4 class="ms-3 mb-2">Phone No. 01 : ' . $row["contact_no"]. '</h4>';
    echo    '<h4 class="ms-3 mb-2" style="left: 15.6%;position: relative;"> 02 : ' . $row["contact_no"] . '</h4>';
    echo '</div>';

    echo '<div class="col custom-border pt-3 pb-3 me-2 mt-1 mb-1 rounded">';
    echo    '<h4 class="ms-3 mt-3">Description : T-Shirts</h4>';
    echo '</div>';

    echo '</div>';
    echo '<div class="col-5 custom-border flex-column mt-1 mb-1">';

    echo '<h1 class="text-center">PROOF OF DELIVERY</h1>';

    echo '<div class="col rounded custom-border h-25 mx-auto" style="width: 97%;"></div>';

    echo '<div class="col d-flex mt-2">';
    echo    '<h3 class="ms-2 me-2">COD AMOUNT :</h3>';
    echo    '<div class="col custom-border me-2"><h3 class="ms-2"> Rs. ' . $row['total_price'] . ' /-</h3></div>';
    echo '</div>';

    echo '<div class="col custom-border rounded mt-1 ms-2 me-2">';
    echo    '<h4 class="ms-2 me-2"> Order No. : TCOFW' . $row['id'] . '</h4>';
    echo '</div>';

    echo '<div class="col custom-border rounded mt-1 ms-2 me-2">';
    echo    '<h4 class="ms-2 me-2"> Weight : ' . $row['total_weight'] . ' Kg</h4>';
    echo '</div>';

    echo '<div class="col custom-border rounded mt-1 ms-2 me-2">';
    echo    '<h4 class="ms-2 me-2"> District : ' . $row['district'] . '</h4>';
    echo    '<h4 class="ms-2 me-2 border-top pt-2"> Nearest City : ' . $row['city'] . '</h4>';
    echo '</div>';

    echo '<div class="col custom-border rounded mt-1 ms-2 me-2 mb-1">';
    echo    '<h4 class="ms-2 me-2"> Name : </h4>';
    echo    '<h4 class="ms-2 me-2"> NIC Number : </h4>';
    echo    '<h4 class="ms-2 me-2"> Date : </h4>';
    echo    '<h4 class="ms-2 me-2"> Signature : </h4>';
    echo '</div>';
    echo '</div>';
    $result->close();
} else {
    echo "No rows found.";
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>

    </div>
</body>
</html> 
